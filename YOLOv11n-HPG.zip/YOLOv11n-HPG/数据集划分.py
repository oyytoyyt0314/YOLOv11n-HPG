# -*- coding: utf-8 -*-
"""
China_MotorBike 全局近重复分组 + 泄漏风险受控的组约束 8:1:1 重划分
=====================================================================

功能：
1. 从原 train / val / test 中汇总全部 1,977 张标注图像
2. 计算全部图像的 64-bit pHash（imagehash.phash 默认 hash_size=8）
3. 对全部图像进行全局两两比较
4. 当 pHash 汉明距离 <= PHASH_THRESHOLD 时建立无向边
5. 使用并查集求连通分量，解决 A~B、B~C 的传递性问题
6. 以“连通分量组”为不可拆分单位，重新做接近 8:1:1 的组约束划分
7. 在分组分配时同时平衡：
   - 图像数
   - 正样本图像数
   - 负样本图像数
   - 裂缝实例总数
   - 单图实例数分箱分布
8. 将新数据复制到独立目录，不修改原始数据
9. 自动重新审计：
   - MD5 跨集合完全重复
   - pHash<=4 跨集合近重复
10. 输出：
   - 新 data.yaml
   - 全局近重复边表
   - 连通分量统计
   - 新划分清单
   - 新旧划分对照
   - 最终审计报告

依赖：
    pip install pillow imagehash pyyaml pandas tqdm

运行：
    python regroup_china_motorbike_group_split.py

重要：
- 本脚本只使用当前 YOLO 单类标签，因此只能平衡 crack 正负样本与实例数量。
- 若后续需要 D00 / D10 / D20 分层，需要再读取 RDD2022 原始 XML。
"""

import os
import math
import random
import shutil
import hashlib
from pathlib import Path
from collections import Counter, defaultdict

import yaml
import pandas as pd
from PIL import Image, ImageOps
import imagehash
from tqdm import tqdm


# =============================================================================
# 0. 配置
# =============================================================================

YAML_PATH = Path(r"E:\yyt\yolov11yyt\rd2022\data.yaml")

# 新数据集输出目录：不会覆盖原数据
OUTPUT_ROOT = Path(r"E:\yyt\yolov11yyt\rd2022_group_split")

# 全局 pHash 近重复阈值
PHASH_THRESHOLD = 4

# imagehash.phash 默认 hash_size=8 -> 8*8 = 64 bit
PHASH_HASH_SIZE = 8

# 目标划分比例
TARGET_RATIOS = {
    "train": 0.8,
    "val": 0.1,
    "test": 0.1,
}

# 随机搜索次数，越大越容易得到更均衡的组级划分
N_RESTARTS = 300

# 固定随机种子
RANDOM_SEED = 42

# 是否复制文件到新目录
COPY_FILES = True

# 如果输出目录存在，是否允许清空后重建
CLEAR_OUTPUT_ROOT = True

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}

# 分配目标各项权重
# 图像数量最重要，其次正负样本与实例总数，再兼顾实例数分箱
W_IMAGES = 5.0
W_POSITIVE = 2.0
W_NEGATIVE = 2.0
W_INSTANCES = 3.0
W_BINS = 1.0

# 实例数分箱
INSTANCE_BINS = ["0", "1", "2", "3-4", "5-9", ">=10"]


# =============================================================================
# 1. 基础工具
# =============================================================================

def load_yaml(yaml_path: Path):
    with open(yaml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def normalize_yaml_path_string(p):
    """
    兼容 YAML 中误写成：
        path: r"E:/xxx"
    的情况。
    """
    p = str(p).strip()
    if len(p) >= 3 and p[0].lower() == "r" and p[1] in ('"', "'") and p[-1] == p[1]:
        p = p[2:-1]
    return p


def resolve_root(cfg, yaml_path: Path):
    p = normalize_yaml_path_string(cfg.get("path", ""))
    root = Path(p)
    if not root.is_absolute():
        root = (yaml_path.parent / root).resolve()
    return root


def resolve_split_dir(root: Path, cfg, split: str):
    p = Path(str(cfg[split]))
    return p if p.is_absolute() else root / p


def infer_label_dir(image_dir: Path):
    parts = list(image_dir.parts)
    lower = [p.lower() for p in parts]
    if "images" in lower:
        i = lower.index("images")
        parts[i] = "labels"
        return Path(*parts)
    return image_dir.parent.parent / "labels" / image_dir.name


def list_images(folder: Path):
    return sorted(
        p for p in folder.rglob("*")
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS
    )


def md5_file(path: Path, chunk_size=1024 * 1024):
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def calc_phash(path: Path):
    with Image.open(path) as img:
        img = ImageOps.exif_transpose(img).convert("RGB")
        return imagehash.phash(img, hash_size=PHASH_HASH_SIZE)


def read_yolo_label(label_path: Path):
    if not label_path.exists():
        return {
            "label_exists": False,
            "instance_count": 0,
            "class_counts": {},
        }

    lines = [
        x.strip()
        for x in label_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if x.strip()
    ]

    class_counts = Counter()
    valid = 0
    for line in lines:
        parts = line.split()
        if not parts:
            continue
        try:
            cls_id = int(float(parts[0]))
            class_counts[cls_id] += 1
            valid += 1
        except Exception:
            continue

    return {
        "label_exists": True,
        "instance_count": valid,
        "class_counts": dict(class_counts),
    }


def instance_bin(n):
    n = int(n)
    if n == 0:
        return "0"
    if n == 1:
        return "1"
    if n == 2:
        return "2"
    if 3 <= n <= 4:
        return "3-4"
    if 5 <= n <= 9:
        return "5-9"
    return ">=10"


# =============================================================================
# 2. 并查集 / 连通分量
# =============================================================================

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra = self.find(a)
        rb = self.find(b)
        if ra == rb:
            return
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1


# =============================================================================
# 3. 汇总 1,977 张图
# =============================================================================

def collect_all_images(cfg, root):
    records = []
    seen_names = {}

    for old_split in ["train", "val", "test"]:
        image_dir = resolve_split_dir(root, cfg, old_split)
        label_dir = infer_label_dir(image_dir)
        images = list_images(image_dir)

        print(f"{old_split:5s}: {len(images)} 张")

        for img_path in images:
            rel = img_path.relative_to(image_dir)
            label_path = label_dir / rel.with_suffix(".txt")

            # 检查 basename 是否重复
            key = img_path.name.lower()
            if key in seen_names:
                raise RuntimeError(
                    "发现不同原始子集中存在同名图像，当前脚本默认文件名唯一：\n"
                    f"  {seen_names[key]}\n"
                    f"  {img_path}"
                )
            seen_names[key] = img_path

            lab = read_yolo_label(label_path)

            records.append({
                "old_split": old_split,
                "filename": img_path.name,
                "image_path": str(img_path),
                "label_path": str(label_path),
                "label_exists": lab["label_exists"],
                "instance_count": int(lab["instance_count"]),
                "positive": int(lab["instance_count"] > 0),
                "negative": int(lab["instance_count"] == 0),
                "instance_bin": instance_bin(lab["instance_count"]),
            })

    df = pd.DataFrame(records)

    if len(df) == 0:
        raise RuntimeError("没有找到任何图像。")

    return df


# =============================================================================
# 4. 计算 MD5 + pHash
# =============================================================================

def compute_hashes(df, cache_csv: Path):
    """
    若缓存完整可复用，避免每次重算图像哈希。
    """
    if cache_csv.exists():
        cache = pd.read_csv(cache_csv)
        needed = {"filename", "md5", "phash"}
        if needed.issubset(cache.columns) and len(cache) == len(df):
            merged = df.merge(
                cache[["filename", "md5", "phash"]],
                on="filename",
                how="left"
            )
            if merged["phash"].notna().all():
                print("检测到完整哈希缓存，直接复用。")
                return merged

    md5s = []
    phashes = []

    print("\n计算 MD5 和 64-bit pHash...")
    for p in tqdm(df["image_path"].tolist(), desc="hash"):
        path = Path(p)
        md5s.append(md5_file(path))
        phashes.append(str(calc_phash(path)))

    out = df.copy()
    out["md5"] = md5s
    out["phash"] = phashes

    out[["filename", "md5", "phash"]].to_csv(
        cache_csv, index=False, encoding="utf-8-sig"
    )
    return out


# =============================================================================
# 5. 全局两两 pHash 建图
# =============================================================================

def build_global_similarity_graph(df, threshold, edges_csv: Path):
    n = len(df)
    hashes = [imagehash.hex_to_hash(x) for x in df["phash"].tolist()]
    uf = UnionFind(n)

    edges = []

    total_pairs = n * (n - 1) // 2
    print("\n" + "=" * 95)
    print("全局 pHash 两两比较")
    print("=" * 95)
    print(f"图像数: {n}")
    print(f"总比较对数: {total_pairs:,}")
    print(f"64-bit pHash 汉明距离阈值: <= {threshold}")
    print()

    pbar = tqdm(total=total_pairs, desc="global-pHash")

    for i in range(n):
        hi = hashes[i]
        for j in range(i + 1, n):
            d = hi - hashes[j]

            if d <= threshold:
                uf.union(i, j)
                edges.append({
                    "index_1": i,
                    "file_1": df.iloc[i]["filename"],
                    "old_split_1": df.iloc[i]["old_split"],
                    "index_2": j,
                    "file_2": df.iloc[j]["filename"],
                    "old_split_2": df.iloc[j]["old_split"],
                    "phash_distance": int(d),
                    "originally_cross_split": (
                        df.iloc[i]["old_split"] != df.iloc[j]["old_split"]
                    ),
                })

            pbar.update(1)

    pbar.close()

    edges_df = pd.DataFrame(edges)
    edges_df.to_csv(edges_csv, index=False, encoding="utf-8-sig")

    # 连通分量
    roots = [uf.find(i) for i in range(n)]

    root_to_gid = {}
    next_gid = 0
    group_ids = []

    for r in roots:
        if r not in root_to_gid:
            root_to_gid[r] = next_gid
            next_gid += 1
        group_ids.append(root_to_gid[r])

    out = df.copy()
    out["group_id"] = group_ids

    return out, edges_df


# =============================================================================
# 6. 构建 group 级统计
# =============================================================================

def build_group_table(df):
    rows = []

    for gid, g in df.groupby("group_id"):
        row = {
            "group_id": int(gid),
            "image_count": len(g),
            "positive_images": int(g["positive"].sum()),
            "negative_images": int(g["negative"].sum()),
            "instance_count": int(g["instance_count"].sum()),
            "filenames": "|".join(g["filename"].tolist()),
        }

        for b in INSTANCE_BINS:
            row[f"bin_{b}"] = int((g["instance_bin"] == b).sum())

        rows.append(row)

    groups = pd.DataFrame(rows)
    groups = groups.sort_values(
        ["image_count", "instance_count"],
        ascending=[False, False]
    ).reset_index(drop=True)

    return groups


# =============================================================================
# 7. 组级 8:1:1 平衡划分
# =============================================================================

def compute_targets(df):
    targets = {}

    totals = {
        "images": len(df),
        "positive": int(df["positive"].sum()),
        "negative": int(df["negative"].sum()),
        "instances": int(df["instance_count"].sum()),
    }

    for b in INSTANCE_BINS:
        totals[f"bin_{b}"] = int((df["instance_bin"] == b).sum())

    for split, ratio in TARGET_RATIOS.items():
        targets[split] = {
            k: v * ratio
            for k, v in totals.items()
        }

    return totals, targets


def blank_state():
    state = {}
    for split in TARGET_RATIOS:
        state[split] = {
            "images": 0,
            "positive": 0,
            "negative": 0,
            "instances": 0,
        }
        for b in INSTANCE_BINS:
            state[split][f"bin_{b}"] = 0
    return state


def add_group_to_state(state, split, row, sign=1):
    state[split]["images"] += sign * int(row["image_count"])
    state[split]["positive"] += sign * int(row["positive_images"])
    state[split]["negative"] += sign * int(row["negative_images"])
    state[split]["instances"] += sign * int(row["instance_count"])

    for b in INSTANCE_BINS:
        state[split][f"bin_{b}"] += sign * int(row[f"bin_{b}"])


def normalized_sq_error(x, target):
    denom = max(float(target), 1.0)
    return ((float(x) - float(target)) / denom) ** 2


def score_state(state, targets):
    score = 0.0

    for split in TARGET_RATIOS:
        score += W_IMAGES * normalized_sq_error(
            state[split]["images"], targets[split]["images"]
        )
        score += W_POSITIVE * normalized_sq_error(
            state[split]["positive"], targets[split]["positive"]
        )
        score += W_NEGATIVE * normalized_sq_error(
            state[split]["negative"], targets[split]["negative"]
        )
        score += W_INSTANCES * normalized_sq_error(
            state[split]["instances"], targets[split]["instances"]
        )

        for b in INSTANCE_BINS:
            score += W_BINS * normalized_sq_error(
                state[split][f"bin_{b}"], targets[split][f"bin_{b}"]
            )

    return score


def greedy_group_assignment(groups, targets, rng):
    """
    大组优先；同大小组随机打散。
    每一步尝试放入 train / val / test，选择全局目标误差最小的方案。
    """
    # 给同规模 group 加随机 tie-break
    work = groups.copy()
    work["_rand"] = [rng.random() for _ in range(len(work))]
    work = work.sort_values(
        ["image_count", "instance_count", "_rand"],
        ascending=[False, False, True]
    ).reset_index(drop=True)

    state = blank_state()
    assignment = {}

    for _, row in work.iterrows():
        candidate_scores = []

        for split in TARGET_RATIOS:
            add_group_to_state(state, split, row, sign=1)
            s = score_state(state, targets)
            add_group_to_state(state, split, row, sign=-1)

            # 额外抑制图像数量严重超额
            img_target = targets[split]["images"]
            prospective = state[split]["images"] + int(row["image_count"])
            overflow = max(0.0, prospective - img_target)
            overflow_penalty = 2.0 * (overflow / max(img_target, 1.0)) ** 2

            candidate_scores.append((s + overflow_penalty, rng.random(), split))

        candidate_scores.sort()
        chosen = candidate_scores[0][2]
        assignment[int(row["group_id"])] = chosen
        add_group_to_state(state, chosen, row, sign=1)

    return assignment, state, score_state(state, targets)


def refine_assignment(groups, assignment, state, targets, rng, max_rounds=8):
    """
    简单局部搜索：
    尝试把单个 group 从当前 split 移到另一个 split，
    如果总体目标更好则接受。
    """
    group_map = {
        int(r["group_id"]): r
        for _, r in groups.iterrows()
    }

    current_score = score_state(state, targets)
    gids = list(group_map.keys())

    for _ in range(max_rounds):
        improved = False
        rng.shuffle(gids)

        for gid in gids:
            row = group_map[gid]
            src = assignment[gid]

            candidates = [s for s in TARGET_RATIOS if s != src]
            rng.shuffle(candidates)

            best_move = None
            best_score = current_score

            for dst in candidates:
                add_group_to_state(state, src, row, sign=-1)
                add_group_to_state(state, dst, row, sign=1)

                s = score_state(state, targets)

                add_group_to_state(state, dst, row, sign=-1)
                add_group_to_state(state, src, row, sign=1)

                if s < best_score:
                    best_score = s
                    best_move = dst

            if best_move is not None:
                add_group_to_state(state, src, row, sign=-1)
                add_group_to_state(state, best_move, row, sign=1)
                assignment[gid] = best_move
                current_score = best_score
                improved = True

        if not improved:
            break

    return assignment, state, current_score


def search_best_group_split(groups, df):
    totals, targets = compute_targets(df)

    best_assignment = None
    best_state = None
    best_score = float("inf")

    master_rng = random.Random(RANDOM_SEED)

    print("\n" + "=" * 95)
    print("组级平衡划分搜索")
    print("=" * 95)
    print(f"随机重启次数: {N_RESTARTS}")

    for r in tqdm(range(N_RESTARTS), desc="split-search"):
        seed = master_rng.randint(0, 2**31 - 1)
        rng = random.Random(seed)

        assignment, state, score = greedy_group_assignment(groups, targets, rng)
        assignment, state, score = refine_assignment(
            groups, assignment, state, targets, rng
        )

        if score < best_score:
            best_score = score
            best_assignment = assignment.copy()
            best_state = {
                s: vals.copy()
                for s, vals in state.items()
            }

    return best_assignment, best_state, best_score, totals, targets


# =============================================================================
# 8. 输出新数据集
# =============================================================================

def prepare_output_root():
    if OUTPUT_ROOT.exists() and CLEAR_OUTPUT_ROOT:
        print(f"\n清空旧输出目录：{OUTPUT_ROOT}")
        shutil.rmtree(OUTPUT_ROOT)

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    for split in TARGET_RATIOS:
        (OUTPUT_ROOT / "images" / split).mkdir(parents=True, exist_ok=True)
        (OUTPUT_ROOT / "labels" / split).mkdir(parents=True, exist_ok=True)

    (OUTPUT_ROOT / "audit").mkdir(parents=True, exist_ok=True)


def copy_dataset(df):
    if not COPY_FILES:
        return

    print("\n复制新划分数据...")
    for _, row in tqdm(df.iterrows(), total=len(df), desc="copy"):
        split = row["new_split"]

        src_img = Path(row["image_path"])
        src_lbl = Path(row["label_path"])

        dst_img = OUTPUT_ROOT / "images" / split / src_img.name
        dst_lbl = OUTPUT_ROOT / "labels" / split / src_img.with_suffix(".txt").name

        shutil.copy2(src_img, dst_img)

        if src_lbl.exists():
            shutil.copy2(src_lbl, dst_lbl)
        else:
            # 若原始负样本无 txt，则创建空标签，方便 YOLO
            dst_lbl.write_text("", encoding="utf-8")


def write_new_yaml(original_cfg):
    names = original_cfg.get("names", {0: "crack"})

    new_cfg = {
        "path": str(OUTPUT_ROOT).replace("\\", "/"),
        "train": "images/train",
        "val": "images/val",
        "test": "images/test",
        "names": names,
    }

    out = OUTPUT_ROOT / "data.yaml"
    with open(out, "w", encoding="utf-8") as f:
        yaml.safe_dump(
            new_cfg,
            f,
            allow_unicode=True,
            sort_keys=False
        )


# =============================================================================
# 9. 新划分审计
# =============================================================================

def audit_new_split(df):
    # MD5 跨集合重复
    md5_cross_pairs = []

    for md5, g in df.groupby("md5"):
        if len(g) < 2:
            continue

        items = g.to_dict("records")
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                if items[i]["new_split"] != items[j]["new_split"]:
                    md5_cross_pairs.append({
                        "file_1": items[i]["filename"],
                        "split_1": items[i]["new_split"],
                        "file_2": items[j]["filename"],
                        "split_2": items[j]["new_split"],
                        "md5": md5,
                    })

    md5_df = pd.DataFrame(md5_cross_pairs)

    # pHash <= threshold 跨集合
    phashes = [imagehash.hex_to_hash(x) for x in df["phash"].tolist()]
    near_cross_pairs = []

    total_pairs = len(df) * (len(df) - 1) // 2
    pbar = tqdm(total=total_pairs, desc="post-audit-pHash")

    rows = df.to_dict("records")

    for i in range(len(df)):
        for j in range(i + 1, len(df)):
            if rows[i]["new_split"] == rows[j]["new_split"]:
                pbar.update(1)
                continue

            d = phashes[i] - phashes[j]
            if d <= PHASH_THRESHOLD:
                near_cross_pairs.append({
                    "file_1": rows[i]["filename"],
                    "split_1": rows[i]["new_split"],
                    "file_2": rows[j]["filename"],
                    "split_2": rows[j]["new_split"],
                    "phash_distance": int(d),
                    "group_1": rows[i]["group_id"],
                    "group_2": rows[j]["group_id"],
                })

            pbar.update(1)

    pbar.close()

    near_df = pd.DataFrame(near_cross_pairs)

    return md5_df, near_df


# =============================================================================
# 10. 汇总统计
# =============================================================================

def make_split_summary(df, split_col):
    rows = []

    for split in ["train", "val", "test"]:
        g = df[df[split_col] == split]

        row = {
            "split": split,
            "images": len(g),
            "ratio": len(g) / len(df),
            "positive_images": int(g["positive"].sum()),
            "negative_images": int(g["negative"].sum()),
            "positive_ratio": float(g["positive"].mean()) if len(g) else 0,
            "instances": int(g["instance_count"].sum()),
            "mean_instances_per_image": float(g["instance_count"].mean()) if len(g) else 0,
            "median_instances_per_image": float(g["instance_count"].median()) if len(g) else 0,
        }

        for b in INSTANCE_BINS:
            row[f"bin_{b}"] = int((g["instance_bin"] == b).sum())

        rows.append(row)

    return pd.DataFrame(rows)


# =============================================================================
# 11. 主程序
# =============================================================================

def main():
    random.seed(RANDOM_SEED)

    if not YAML_PATH.exists():
        raise FileNotFoundError(f"找不到 YAML：{YAML_PATH}")

    cfg = load_yaml(YAML_PATH)
    root = resolve_root(cfg, YAML_PATH)

    print("=" * 95)
    print("China_MotorBike 全局近重复分组 + 组约束 8:1:1 重划分")
    print("=" * 95)
    print(f"原数据 YAML : {YAML_PATH}")
    print(f"原数据根目录 : {root}")
    print(f"新数据输出目录: {OUTPUT_ROOT}")
    print(f"pHash         : {PHASH_HASH_SIZE * PHASH_HASH_SIZE}-bit")
    print(f"Hamming 阈值  : <= {PHASH_THRESHOLD}")
    print()

    # -------------------------------------------------------------------------
    # STEP 1 汇总原数据
    # -------------------------------------------------------------------------
    print("\n[STEP 1] 汇总全部图像")
    df = collect_all_images(cfg, root)

    print(f"\n总图像数: {len(df)}")
    print(f"总正样本图像: {df['positive'].sum()}")
    print(f"总负样本图像: {df['negative'].sum()}")
    print(f"总 crack instances: {df['instance_count'].sum()}")

    # 输出目录先建立 audit 缓存目录
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    temp_audit = OUTPUT_ROOT / "_temp_audit"
    temp_audit.mkdir(parents=True, exist_ok=True)

    # -------------------------------------------------------------------------
    # STEP 2 hash
    # -------------------------------------------------------------------------
    print("\n[STEP 2] 计算图像哈希")
    hash_cache = temp_audit / "hash_cache.csv"
    df = compute_hashes(df, hash_cache)

    # -------------------------------------------------------------------------
    # STEP 3 全局建图
    # -------------------------------------------------------------------------
    print("\n[STEP 3] 全局 pHash 建图 + 连通分量")
    edges_csv = temp_audit / "global_phash_edges.csv"
    df, edges_df = build_global_similarity_graph(
        df,
        PHASH_THRESHOLD,
        edges_csv
    )

    # group table
    groups = build_group_table(df)

    n_groups = len(groups)
    multi_groups = int((groups["image_count"] >= 2).sum())
    max_group = int(groups["image_count"].max())

    print(f"\n全局相似性边数量: {len(edges_df)}")
    print(f"图像组总数: {n_groups}")
    print(f"包含 >=2 张图像的组数: {multi_groups}")
    print(f"最大组图像数: {max_group}")

    # -------------------------------------------------------------------------
    # STEP 4 group-aware split
    # -------------------------------------------------------------------------
    print("\n[STEP 4] 搜索组约束平衡 8:1:1 划分")
    assignment, state, best_score, totals, targets = search_best_group_split(
        groups,
        df
    )

    df["new_split"] = df["group_id"].map(assignment)

    if df["new_split"].isna().any():
        raise RuntimeError("存在未分配 group。")

    # 检查一个 group 是否只进入一个 split
    group_split_count = df.groupby("group_id")["new_split"].nunique()
    if int(group_split_count.max()) != 1:
        raise RuntimeError("错误：某个连通分量被拆分到了多个子集。")

    old_summary = make_split_summary(df, "old_split")
    new_summary = make_split_summary(df, "new_split")

    print("\n原始划分：")
    print(old_summary.to_string(index=False))

    print("\n新组约束划分：")
    print(new_summary.to_string(index=False))

    # -------------------------------------------------------------------------
    # STEP 5 正式创建输出
    # -------------------------------------------------------------------------
    print("\n[STEP 5] 创建新的数据集目录")
    # 这里先保存 temp 中的 hash 和 edge
    hash_cache_df = pd.read_csv(hash_cache)
    edges_save = edges_df.copy()

    prepare_output_root()

    audit_dir = OUTPUT_ROOT / "audit"

    hash_cache_df.to_csv(
        audit_dir / "01_hash_cache.csv",
        index=False,
        encoding="utf-8-sig"
    )
    edges_save.to_csv(
        audit_dir / "02_global_phash_edges.csv",
        index=False,
        encoding="utf-8-sig"
    )

    # group表
    group_split_map = {
        gid: assignment[gid]
        for gid in assignment
    }
    groups_out = groups.copy()
    groups_out["new_split"] = groups_out["group_id"].map(group_split_map)
    groups_out.to_csv(
        audit_dir / "03_connected_components_groups.csv",
        index=False,
        encoding="utf-8-sig"
    )

    # image级清单
    image_manifest = df[
        [
            "filename",
            "old_split",
            "new_split",
            "group_id",
            "positive",
            "negative",
            "instance_count",
            "instance_bin",
            "md5",
            "phash",
            "image_path",
            "label_path",
        ]
    ].copy()

    image_manifest.to_csv(
        audit_dir / "04_image_manifest_old_vs_new.csv",
        index=False,
        encoding="utf-8-sig"
    )

    # summary
    old_summary.to_csv(
        audit_dir / "05_old_split_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )
    new_summary.to_csv(
        audit_dir / "06_new_split_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )

    # 复制新数据 + YAML
    copy_dataset(df)
    write_new_yaml(cfg)

    # -------------------------------------------------------------------------
    # STEP 6 重新审计
    # -------------------------------------------------------------------------
    print("\n[STEP 6] 对新划分进行跨集合重复审计")
    md5_cross_df, near_cross_df = audit_new_split(df)

    md5_cross_df.to_csv(
        audit_dir / "07_postsplit_cross_md5_duplicates.csv",
        index=False,
        encoding="utf-8-sig"
    )
    near_cross_df.to_csv(
        audit_dir / "08_postsplit_cross_phash_le4_pairs.csv",
        index=False,
        encoding="utf-8-sig"
    )

    print(f"\n新划分跨集合 MD5 完全重复对: {len(md5_cross_df)}")
    print(f"新划分跨集合 pHash<={PHASH_THRESHOLD} 图像对: {len(near_cross_df)}")

    # -------------------------------------------------------------------------
    # STEP 7 输出最终报告
    # -------------------------------------------------------------------------
    print("\n[STEP 7] 输出最终报告")

    # group size stats
    group_sizes = groups["image_count"].tolist()

    report = []
    report.append("=" * 95)
    report.append("China_MotorBike 泄漏风险受控的组约束划分报告")
    report.append("=" * 95)
    report.append("")
    report.append("[A] 原始数据")
    report.append(f"总图像数: {len(df)}")
    report.append(f"正样本图像: {int(df['positive'].sum())}")
    report.append(f"负样本图像: {int(df['negative'].sum())}")
    report.append(f"总 crack instances: {int(df['instance_count'].sum())}")
    report.append("")
    report.append("[B] 全局感知相似性图")
    report.append(f"pHash 位数: {PHASH_HASH_SIZE * PHASH_HASH_SIZE}")
    report.append(f"pHash 汉明距离阈值: <= {PHASH_THRESHOLD}")
    report.append(f"全局近重复边数: {len(edges_df)}")
    report.append(f"图像组总数: {n_groups}")
    report.append(f"包含两张及以上图像的组数: {multi_groups}")
    report.append(f"单图组数: {int((groups['image_count'] == 1).sum())}")
    report.append(f"最大组包含图像数: {max_group}")
    report.append("")
    report.append("[C] 原始 8:1:1")
    for _, r in old_summary.iterrows():
        report.append(
            f"{r['split']}: "
            f"{int(r['images'])} images, "
            f"{int(r['positive_images'])} positive, "
            f"{int(r['negative_images'])} negative, "
            f"{int(r['instances'])} instances"
        )
    report.append("")
    report.append("[D] 新组约束划分")
    for _, r in new_summary.iterrows():
        report.append(
            f"{r['split']}: "
            f"{int(r['images'])} images "
            f"({r['ratio']*100:.2f}%), "
            f"{int(r['positive_images'])} positive, "
            f"{int(r['negative_images'])} negative, "
            f"{int(r['instances'])} instances, "
            f"mean instances/image={r['mean_instances_per_image']:.4f}"
        )
    report.append("")
    report.append("[E] 新划分跨集合审计")
    report.append(f"跨集合 MD5 完全重复图像对: {len(md5_cross_df)}")
    report.append(
        f"跨集合 pHash 汉明距离 <= {PHASH_THRESHOLD} 图像对: {len(near_cross_df)}"
    )
    report.append("")
    report.append("[F] 方法解释")
    report.append(
        "全部图像先进行全局 pHash 比较，以图像为节点、pHash 汉明距离不大于阈值为边，"
        "再使用连通分量形成不可拆分图像组。"
    )
    report.append(
        "因此若 A-B 相似、B-C 相似，即使 A-C 未直接满足阈值，A/B/C 仍归入同一连通分量，"
        "后续不会被拆分至不同数据子集。"
    )
    report.append("")
    report.append(
        "注意：该方法降低可检测视觉近重复引起的数据泄漏风险，但由于公开数据不含原始路线、"
        "GPS、拍摄时间和序列 ID，不能证明完全消除了所有潜在空间/时间相关性。"
    )
    report.append(
        "建议论文中表述为：leakage-risk-controlled group-constrained split。"
    )
    report.append("")
    report.append(f"优化目标得分: {best_score:.8f}")

    report_text = "\n".join(report)

    (audit_dir / "09_FINAL_GROUP_SPLIT_REPORT.txt").write_text(
        report_text,
        encoding="utf-8"
    )

    # 删除 temp
    if temp_audit.exists():
        shutil.rmtree(temp_audit, ignore_errors=True)

    print("\n" + report_text)

    print("\n" + "=" * 95)
    print("全部完成")
    print("=" * 95)
    print(f"新数据集目录: {OUTPUT_ROOT}")
    print(f"新训练 YAML : {OUTPUT_ROOT / 'data.yaml'}")
    print(f"审计结果目录: {audit_dir}")
    print("")
    print("论文中最需要的数字在：")
    print("  03_connected_components_groups.csv")
    print("  06_new_split_summary.csv")
    print("  07_postsplit_cross_md5_duplicates.csv")
    print("  08_postsplit_cross_phash_le4_pairs.csv")
    print("  09_FINAL_GROUP_SPLIT_REPORT.txt")


if __name__ == "__main__":
    main()
