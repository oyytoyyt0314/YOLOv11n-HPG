import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["ADown", "ADownV2", "HIDown"]


class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        if p is None:
            p = k // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class ADown(nn.Module):
    def __init__(self, c1, c2):
        super().__init__()
        if c1 % 2 or c2 % 2:
            raise ValueError("ADown requires even input and output channel counts")
        c_ = c2 // 2
        self.cv1 = Conv(c1 // 2, c_, 3, 2, 1)
        self.cv2 = Conv(c1 // 2, c_, 1, 1, 0)

    def forward(self, x):
        x = F.avg_pool2d(x, 2, 1, 0, count_include_pad=False)
        x1, x2 = x.chunk(2, dim=1)
        x1 = self.cv1(x1)
        x2 = F.max_pool2d(x2, 3, 2, 1)
        x2 = self.cv2(x2)
        return torch.cat((x1, x2), dim=1)


class HIDown(nn.Module):
    def __init__(self, c1, c2, shuffle_groups=4):
        super().__init__()
        if c1 % 2 or c2 % 2:
            raise ValueError("HIDown requires even input and output channel counts")
        if (c1 // 2) % shuffle_groups:
            raise ValueError("The branch channel count must be divisible by shuffle_groups")

        c_ = c2 // 2
        self.shuffle_groups = shuffle_groups
        self.cv1_dw = nn.Conv2d(c1 // 2, c1 // 2, 3, 2, 1, groups=c1 // 2, bias=False)
        self.cv1_bn1 = nn.BatchNorm2d(c1 // 2)
        self.cv1_pw = nn.Conv2d(c1 // 2, c_, 1, 1, 0, bias=False)
        self.cv1_bn2 = nn.BatchNorm2d(c_)
        self.cv2 = Conv(c1 // 2, c_, 1, 1, 0)
        self.act = nn.SiLU(inplace=True)
        self.gamma = nn.Parameter(torch.ones(1, c2, 1, 1))

    @staticmethod
    def channel_shuffle(x, groups):
        b, c, h, w = x.shape
        if c % groups:
            raise ValueError("The channel count must be divisible by groups")
        x = x.reshape(b, groups, c // groups, h, w)
        x = x.transpose(1, 2).contiguous()
        return x.reshape(b, c, h, w)

    def forward(self, x):
        x_avg = F.avg_pool2d(x, 2, 1, 0, count_include_pad=False)
        x_max = F.max_pool2d(x, 2, 1, 0)
        x = 0.5 * (x_avg + x_max)
        x1, x2 = x.chunk(2, dim=1)

        x1 = self.act(self.cv1_bn1(self.cv1_dw(x1)))
        x1 = self.act(self.cv1_bn2(self.cv1_pw(x1)))

        x2 = F.max_pool2d(x2, 3, 2, 1)
        x2 = self.channel_shuffle(x2, self.shuffle_groups)
        x2 = self.cv2(x2)

        return torch.cat((x1, x2), dim=1) * self.gamma


ADownV2 = HIDown
