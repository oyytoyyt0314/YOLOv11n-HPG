import torch
import torch.nn as nn

__all__ = ["GSConv", "OSAGSBlock"]


def autopad(k, p=None):
    if p is not None:
        return p
    return k // 2 if isinstance(k, int) else [x // 2 for x in k]


class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        return self.act(self.conv(x))


class GSConv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        super().__init__()
        if c2 % 2:
            raise ValueError("GSConv requires an even output channel count")
        c_ = c2 // 2
        self.cv1 = Conv(c1, c_, k, s, g=g, act=act)
        self.cv2 = Conv(c_, c_, 5, 1, g=c_, act=act)

    @staticmethod
    def channel_shuffle(x):
        b, c, h, w = x.shape
        if c % 2:
            raise ValueError("GSConv channel count must be even")
        x = x.reshape(b, 2, c // 2, h, w)
        x = x.transpose(1, 2).contiguous()
        return x.reshape(b, c, h, w)

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = self.cv2(x1)
        return self.channel_shuffle(torch.cat((x1, x2), dim=1))


class DepthwiseConv(nn.Module):
    def __init__(self, channels, kernel_size):
        super().__init__()
        self.conv = nn.Conv2d(
            channels,
            channels,
            kernel_size,
            1,
            kernel_size // 2,
            groups=channels,
            bias=False,
        )
        self.bn = nn.BatchNorm2d(channels)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class OSAGSBlock(nn.Module):
    def __init__(self, c1, c2, kernel_sizes=(3, 5, 7), expansion=1.0):
        super().__init__()
        if not kernel_sizes or any(k % 2 == 0 for k in kernel_sizes):
            raise ValueError("kernel_sizes must contain odd positive integers")
        if any(k < 1 for k in kernel_sizes):
            raise ValueError("kernel_sizes must contain odd positive integers")

        hidden = max(1, int(c2 * expansion))
        self.cv1 = Conv(c1, hidden, 1, 1)
        self.branches = nn.ModuleList(
            DepthwiseConv(hidden, k) for k in kernel_sizes
        )
        self.cv2 = Conv(hidden * len(kernel_sizes), c2, 1, 1, act=False)
        self.gamma = nn.Parameter(torch.ones(1, c2, 1, 1))
        self.shortcut = nn.Identity() if c1 == c2 else Conv(c1, c2, 1, 1, act=False)

    def forward(self, x):
        features = self.cv1(x)
        multi_scale = torch.cat([branch(features) for branch in self.branches], dim=1)
        aggregated = self.cv2(multi_scale) * self.gamma
        return aggregated + self.shortcut(x)
