import math

import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["AxialMultiScaleAttention", "MLCA", "PSA_SMLCA"]


class Conv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        if p is None:
            p = k // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class AxialMultiScaleAttention(nn.Module):
    def __init__(self, c1, c2=None, group_kernel_sizes=(3, 5, 7, 9)):
        super().__init__()
        c2 = c1 if c2 is None else c2
        if c1 != c2:
            raise ValueError("AxialMultiScaleAttention requires matching input and output channels")
        if c1 % len(group_kernel_sizes):
            raise ValueError("Channels must be divisible by the number of groups")
        if any(k % 2 == 0 for k in group_kernel_sizes):
            raise ValueError("All directional kernels must be odd")

        self.group_channels = c1 // len(group_kernel_sizes)
        self.group_kernel_sizes = group_kernel_sizes
        self.dwc_h = nn.ModuleList(
            nn.Conv1d(
                self.group_channels,
                self.group_channels,
                kernel_size=k,
                padding=k // 2,
                groups=self.group_channels,
                bias=False,
            )
            for k in group_kernel_sizes
        )
        self.dwc_w = nn.ModuleList(
            nn.Conv1d(
                self.group_channels,
                self.group_channels,
                kernel_size=k,
                padding=k // 2,
                groups=self.group_channels,
                bias=False,
            )
            for k in group_kernel_sizes
        )
        self.bn_h = nn.BatchNorm1d(c1)
        self.bn_w = nn.BatchNorm1d(c1)

    def forward(self, x):
        _, _, h, w = x.shape
        descriptor_h = x.mean(dim=3)
        descriptor_w = x.mean(dim=2)
        groups_h = descriptor_h.chunk(len(self.group_kernel_sizes), dim=1)
        groups_w = descriptor_w.chunk(len(self.group_kernel_sizes), dim=1)

        weight_h = torch.cat(
            [conv(group) for conv, group in zip(self.dwc_h, groups_h)], dim=1
        )
        weight_w = torch.cat(
            [conv(group) for conv, group in zip(self.dwc_w, groups_w)], dim=1
        )
        weight_h = torch.sigmoid(self.bn_h(weight_h)).unsqueeze(-1)
        weight_w = torch.sigmoid(self.bn_w(weight_w)).unsqueeze(-2)
        return x * weight_h * weight_w


class MLCA(nn.Module):
    def __init__(self, c1, c2=None, local_size=5, gamma=2, b=1, alpha=0.5):
        super().__init__()
        c2 = c1 if c2 is None else c2
        if c1 != c2:
            raise ValueError("MLCA requires matching input and output channels")
        if local_size < 1:
            raise ValueError("local_size must be positive")

        t = int(abs((math.log2(c1) + b) / gamma))
        kernel_size = max(3, t if t % 2 else t + 1)
        self.local_size = local_size
        self.conv_global = nn.Conv1d(
            1, 1, kernel_size, padding=kernel_size // 2, bias=False
        )
        self.conv_local = nn.Conv1d(
            1, 1, kernel_size, padding=kernel_size // 2, bias=False
        )
        self.local_pool = nn.AdaptiveAvgPool2d(local_size)
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.alpha = nn.Parameter(torch.tensor(float(alpha)))

    def forward(self, x):
        b, c, h, w = x.shape
        s = self.local_size
        local_descriptor = self.local_pool(x)
        global_descriptor = self.global_pool(local_descriptor)

        local_logits = local_descriptor.reshape(b, c, s * s)
        local_logits = local_logits.transpose(1, 2).reshape(b * s * s, 1, c)
        local_logits = self.conv_local(local_logits)
        local_logits = local_logits.reshape(b, s * s, c).transpose(1, 2)
        local_logits = local_logits.reshape(b, c, s, s)

        global_logits = self.conv_global(global_descriptor.reshape(b, 1, c))
        global_logits = global_logits.reshape(b, c, 1, 1)

        logits = self.alpha * local_logits + (1.0 - self.alpha) * global_logits
        logits = F.interpolate(logits, size=(h, w), mode="nearest")
        return x * torch.sigmoid(logits)


class PSA_SMLCA_Block(nn.Module):
    def __init__(
        self,
        channels,
        local_size=5,
        alpha=0.5,
        group_kernel_sizes=(3, 5, 7, 9),
        ffn_ratio=2.0,
    ):
        super().__init__()
        self.spatial_attention = AxialMultiScaleAttention(channels, group_kernel_sizes=group_kernel_sizes)
        self.channel_attention = MLCA(channels, local_size=local_size, alpha=alpha)
        hidden = max(1, int(channels * ffn_ratio))
        self.ffn = nn.Sequential(
            Conv(channels, hidden, 1, 1),
            Conv(hidden, channels, 1, 1, act=False),
        )

    def forward(self, x):
        x = self.spatial_attention(x)
        x = self.channel_attention(x)
        return x + self.ffn(x)


class PSA_SMLCA(nn.Module):
    def __init__(
        self,
        c1,
        c2=None,
        n=1,
        e=0.5,
        local_size=5,
        alpha=0.5,
        group_kernel_sizes=(3, 5, 7, 9),
        ffn_ratio=2.0,
    ):
        super().__init__()
        c2 = c1 if c2 is None else c2
        if n < 1:
            raise ValueError("n must be at least one")

        hidden = int(c2 * e)
        if hidden < 1 or hidden % len(group_kernel_sizes):
            raise ValueError("The attention channels must be divisible by the number of groups")

        self.hidden_channels = hidden
        self.cv1 = Conv(c1, 2 * hidden, 1, 1)
        self.blocks = nn.Sequential(
            *(
                PSA_SMLCA_Block(
                    hidden,
                    local_size=local_size,
                    alpha=alpha,
                    group_kernel_sizes=group_kernel_sizes,
                    ffn_ratio=ffn_ratio,
                )
                for _ in range(n)
            )
        )
        self.cv2 = Conv(2 * hidden, c2, 1, 1)

    def forward(self, x):
        identity, attention = self.cv1(x).chunk(2, dim=1)
        attention = self.blocks(attention)
        return self.cv2(torch.cat((identity, attention), dim=1))


