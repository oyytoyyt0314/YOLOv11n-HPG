import warnings
import sys
import os

warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(r"E:\yyt\开源代码\ultralytics-main-FocalModulation-Slimneak+WTConv\YOLOv11n-HPG.yaml")

    model.train(
        data=r"E:\yyt\yolov11yyt\rd2022_group_split\data.yaml",
        cache='disk',
        imgsz=640,
        patience=30,
        epochs=200,
        fraction=1,
        single_cls=False,  # 是否是单类别检测
        batch=4,
        close_mosaic=0,
        workers=2,
        device='0',
        optimizer='SGD',  # using SGD
        # resume='runs/train/exp21/weights/last.pt', # 如过想续训就设置last.pt的地址
        amp=True,  # 如果出现训练损失为Nan可以关闭amp
        project='runs/train/1yolo11-rd2022/7号.yaml',
        name='200',
        pretrained=False,  # 关键：禁用预训练权重，从随机初始化开始训练
        )

from multiprocessing import freeze_support
from ultralytics import RTDETR


def main():

    model = RTDETR(
        r""
        r""
    )

    model.train(
        data=r"",

        epochs=200,
        imgsz=640,
        batch=8,

        optimizer="SGD",
        lr0=0.01,
        momentum=0.937,
        weight_decay=0.0005,

        cos_lr=True,
        patience=30,

        pretrained=False,

        device=0,
        workers=8,

        mosaic=1.0,
        translate=0.1,

        project=r"",
        name="",

        seed=0,
        deterministic=True
    )


if __name__ == "__main__":
    freeze_support()
    main()